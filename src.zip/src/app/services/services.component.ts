import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}



/*

import { Injectable } from '@angular/core';
import { HttpClient,HttpParams,HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { FormGroup } from '@angular/forms';
import {map,catchError} from 'rxjs/operators';
import { IfStmt } from '@angular/compiler';
import { Profile } from '../profile';
import { UserProfileComponent } from '../user-profile/user-profile.component';
import { Friend } from '../friend';
import { Post } from '../post';
import { Message } from '../message';


@Injectable({
  providedIn: 'root'
})
export class CapBookService {
  profile:Profile;
  private userProfile=new BehaviorSubject(this.profile);
  currentProfile=this.userProfile.asObservable();
  changeProfile(profile:Profile){
    this.userProfile.next(profile);
  }
  constructor(private httpClient: HttpClient) { }

  public userRegistration(registrationForm:FormGroup):Observable<string>{
    let body = JSON.parse(JSON.stringify(registrationForm.value));
    return this.httpClient.post<string>("http://localhost:8085/registerUser",body).pipe(catchError(this.handleError));
 }
  
  public userLogin(loginForm:FormGroup):Observable<Profile>{
     let body=JSON.parse(JSON.stringify(loginForm.value));
     return this.httpClient.post<Profile>("http://localhost:8085/loginUser",body).pipe(catchError(this.handleError));     
  }
  public logout():Observable<Profile>{
    return this.httpClient.get<Profile>("http://localhost:8085/logout");
  }
  public editProfile(editProfileForm:FormGroup):Observable<Profile>{
    let body=JSON.parse(JSON.stringify(editProfileForm.value));
    return this.httpClient.post<Profile>("http://localhost:8085/editProfile",body).pipe(catchError(this.handleError));     
 }
 public forgotPassword(forgetPasswordForm:FormGroup):Observable<Profile>{
  let body=JSON.parse(JSON.stringify(forgetPasswordForm.value));
  return this.httpClient.post<Profile>("http://localhost:8085/forgotPassword",body).pipe(catchError(this.handleError));     
 }
 public findFriends(name:string):Observable<Profile[]>{
  let params = new HttpParams();
  console.log(name);
  params=params.set('name',name);
  return this.httpClient.get<Profile[]>("http://localhost:8085/findUsers",{params:params}).pipe(catchError(this.handleError));     
 }
 public myFriends():Observable<Profile[]>{
  return this.httpClient.get<Profile[]>("http://localhost:8085/getFriendList").pipe(catchError(this.handleError));     
 }
 public myFriendRequests():Observable<Profile[]>{
  return this.httpClient.get<Profile[]>("http://localhost:8085/viewFriendRequests").pipe(catchError(this.handleError));     
 }
 
public changePassword(newPassword:string):Observable<Profile>{
  let params = new HttpParams();
  console.log(newPassword);
  params=params.set('password',newPassword);
  //let body=JSON.parse(JSON.stringify(newPassword));
  return this.httpClient.get<Profile>("http://localhost:8085/changePassword",{params:params}).pipe(catchError(this.handleError));     
}

public postFile(fileToUpload: File):any {
  const formData: FormData = new FormData();
  formData.append('Image', fileToUpload, fileToUpload.name);
  return this.httpClient.post("http://localhost:8085/setProfilePic", formData).pipe( map(() => { return true; }),
  catchError(this.handleError));
}
public addFriend(toUserId:string): Observable<Friend>{
  let params = new HttpParams();
  params=params.set('toUserId',toUserId);
  return this.httpClient.get<Friend>("http://localhost:8085/addFriend",{params:params}).pipe(catchError(this.handleError));
}
public sendMessage(message:string,receiverEmailId:string): Observable<string>{
  let params = new HttpParams();
  params=params.set('message',message);
  params=params.set('receiverEmailId',receiverEmailId);
  return this.httpClient.get<string>("http://localhost:8085/sendMessage",{params:params}).pipe(catchError(this.handleError));
}
public createPost(postForm:FormGroup):Observable<Post>{
  let body=JSON.parse(JSON.stringify(postForm.value));
  return this.httpClient.post<Post>("http://localhost:8085/createPost",body).pipe(catchError(this.handleError));     
 }
 
 public myPosts():Observable<Post[]>{
  return this.httpClient.get<Post[]>("http://localhost:8085/getPosts").pipe(catchError(this.handleError));     
 }
 public sentMessages():Observable<Message[]>{
  return this.httpClient.get<Message[]>("http://localhost:8085/viewSentMessages").pipe(catchError(this.handleError));     
 }
 public receivedMessages():Observable<Message[]>{
  return this.httpClient.get<Message[]>("http://localhost:8085/viewReceivedMessages").pipe(catchError(this.handleError));     
 }
 
  // error Handler
  private handleError(error: any){
    if(error instanceof ErrorEvent){
      console.error(`1 An ErrorEvent occurred: `,error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}`);
    }else if(error instanceof TypeError){
      console.error(`3 TypeError has occurred ${error.message}, body was: ${error.stack}`);
      return throwError(`TypeError has occurred ${error.message}, body was: ${error.stack}`);
    }
  }

  
}*/