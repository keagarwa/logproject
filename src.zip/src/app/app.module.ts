import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import {MatToolbarModule} from '@angular/material';
import { LogInPageComponent } from './log-in-page/log-in-page.component'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterPageComponent } from './register-page/register-page.component';
import {RouterModule} from '@angular/router';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ServicesComponent } from './services/services.component';
@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    LogInPageComponent,
    RegisterPageComponent,
    ForgetPasswordComponent,
    ServicesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatToolbarModule,
    FormsModule,
    ReactiveFormsModule, 
    RouterModule.forRoot([
      {path:'register',component:RegisterPageComponent},
      {path: 'forgetPassword', component:ForgetPasswordComponent},
      { path: '**', redirectTo: '' }
    ])
    ],
  exports:
  [
    MatToolbarModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 

}
